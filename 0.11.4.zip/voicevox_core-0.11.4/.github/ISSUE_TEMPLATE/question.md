---
name: Question
about: 質問 (既存のIssueや一般事例を良く調べてからしてください)
labels: question
---

## 質問の内容

<!-- ここに記載してください -->

## OSの種類/ディストリ/バージョン

<!--
なるべく詳しく書いてください 記述例:
*   Windows 10 Pro 64bit (10.0.10586)
*   macOS Sierra
*   Linux fedora 23 64bit
*   Others
-->

## その他

<!-- 関連して何か気がついたこと、気になることがあればココに書いてください -->
